<?php include_once(__DIR__ . '/inc/main.php'); ?>
<?php echo get_header_tmpl(); ?>
<div class="page-index"></div>
<?php echo get_footer_tmpl(); ?>
