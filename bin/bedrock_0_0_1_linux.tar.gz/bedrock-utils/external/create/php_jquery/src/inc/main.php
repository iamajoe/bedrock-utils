<?php
include_once(__DIR__ . '/../components/header.php');
include_once(__DIR__ . '/../components/footer.php');
?>
